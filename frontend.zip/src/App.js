import logo from './logo.svg';
import './App.css';
import Card from './card'

function App() {
  return (
    <div>
    <Card/>
    </div>
  );
}

export default App;
